@echo off
chcp 65001 >nul
title ZEFIR AI - Автообновление

:: ===== НАСТРОЙКИ =====
set "REPO_URL=https://raw.githubusercontent.com/YOUR_USERNAME/zefir-ai/main"
set "VERSION_URL=%REPO_URL%/version.txt"
set "SERVER_URL=%REPO_URL%/ai_server.py"
set "UPDATER_URL=%REPO_URL%/zefir_updater.bat"
set "LOCAL_VERSION_FILE=version.txt"
set "LOCAL_SERVER=ai_server.py"
set "BACKUP_DIR=zefir_backups"
set "UPDATE_LOG=update_log.txt"

:: ===== ПРОВЕРКА ИНТЕРНЕТА =====
echo.
echo ╔══════════════════════════════════════════╗
echo ║   ⚡ ZEFIR AI - АВТООБНОВЛЕНИЕ         ║
echo ╚══════════════════════════════════════════╝
echo.
echo [1/6] Проверка подключения...
ping -n 2 8.8.8.8 >nul 2>&1
if %errorlevel% neq 0 (
    echo [ОШИБКА] Нет интернета. Обновление невозможно.
    echo Нажми любую клавишу для выхода...
    pause >nul
    exit /b 1
)
echo [OK] Интернет доступен

:: ===== СОЗДАНИЕ ПАПОК =====
mkdir "%BACKUP_DIR%" 2>nul

:: ===== ПРОВЕРКА ТЕКУЩЕЙ ВЕРСИИ =====
echo.
echo [2/6] Проверка текущей версии...
set "CURRENT_VERSION=0.0.0"
if exist "%LOCAL_VERSION_FILE%" (
    set /p CURRENT_VERSION=<"%LOCAL_VERSION_FILE%"
    echo Текущая версия: %CURRENT_VERSION%
) else (
    echo Файл версии не найден. Будет установлена последняя версия.
)

:: ===== ПОЛУЧЕНИЕ ВЕРСИИ С СЕРВЕРА =====
echo.
echo [3/6] Проверка версии на сервере...
curl -s -o "%TEMP%\zefir_version_remote.txt" "%VERSION_URL%" 2>nul
if %errorlevel% neq 0 (
    echo [ОШИБКА] Не удалось получить версию с сервера.
    echo Проверь URL: %VERSION_URL%
    pause
    exit /b 1
)

set /p REMOTE_VERSION=<"%TEMP%\zefir_version_remote.txt"
echo Серверная версия: %REMOTE_VERSION%

:: ===== СРАВНЕНИЕ ВЕРСИЙ =====
echo.
echo [4/6] Сравнение версий...

:: Конвертируем версии в числа для сравнения
for /f "tokens=1-3 delims=." %%a in ("%CURRENT_VERSION%") do (
    set /a "CURR_VER=%%a*10000+%%b*100+%%c"
)
for /f "tokens=1-3 delims=." %%a in ("%REMOTE_VERSION%") do (
    set /a "REMOTE_VER=%%a*10000+%%b*100+%%c"
)

if %REMOTE_VER% GTR %CURR_VER% (
    echo [ОБНАРУЖЕНО] Новая версия доступна!
    echo %CURRENT_VERSION% → %REMOTE_VERSION%
    goto :UPDATE
)

if %REMOTE_VER% EQU %CURR_VER% (
    echo [OK] У вас уже последняя версия: %CURRENT_VERSION%
    goto :CHECK_UPDATER
)

if %REMOTE_VER% LSS %CURR_VER% (
    echo [ИНФО] Ваша версия (%CURRENT_VERSION%) новее серверной (%REMOTE_VERSION%)
    echo Возможно у вас бета-версия.
    goto :CHECK_UPDATER
)

:: ===== ОБНОВЛЕНИЕ =====
:UPDATE
echo.
echo [5/6] Установка обновления...
echo.

:: Создаём бэкап
echo Создаю бэкап текущей версии...
set "BACKUP_NAME=backup_%CURRENT_VERSION%_%date:~-4,4%%date:~-7,2%%date:~-10,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
set "BACKUP_NAME=%BACKUP_NAME: =0%"
mkdir "%BACKUP_DIR%\%BACKUP_NAME%" 2>nul

if exist "%LOCAL_SERVER%" (
    copy "%LOCAL_SERVER%" "%BACKUP_DIR%\%BACKUP_NAME%\%LOCAL_SERVER%" >nul
    echo Бэкап сохранён: %BACKUP_DIR%\%BACKUP_NAME%
)
if exist "%LOCAL_VERSION_FILE%" (
    copy "%LOCAL_VERSION_FILE%" "%BACKUP_DIR%\%BACKUP_NAME%\%LOCAL_VERSION_FILE%" >nul
)

:: Скачиваем новую версию
echo.
echo Скачиваю обновление...
echo URL: %SERVER_URL%

curl -s -L -o "%TEMP%\zefir_server_new.py" "%SERVER_URL%" 2>nul
if %errorlevel% neq 0 (
    echo [ОШИБКА] Не удалось скачать сервер.
    echo Пробую запасной метод...
    powershell -Command "Invoke-WebRequest -Uri '%SERVER_URL%' -OutFile '%TEMP%\zefir_server_new.py'" 2>nul
)

:: Проверяем, скачался ли файл
if not exist "%TEMP%\zefir_server_new.py" (
    echo [КРИТИЧЕСКАЯ ОШИБКА] Не удалось скачать обновление.
    pause
    exit /b 1
)

:: Проверяем размер файла
for %%A in ("%TEMP%\zefir_server_new.py") do set "FILE_SIZE=%%~zA"
if %FILE_SIZE% LSS 1000 (
    echo [ОШИБКА] Скачанный файл повреждён (размер: %FILE_SIZE% байт)
    pause
    exit /b 1
)

echo Скачано: %FILE_SIZE% байт

:: Заменяем файл
echo.
echo Устанавливаю новую версию...
copy /Y "%TEMP%\zefir_server_new.py" "%LOCAL_SERVER%" >nul

:: Сохраняем новую версию
echo %REMOTE_VERSION%> "%LOCAL_VERSION_FILE%"

:: Чистим временные файлы
del "%TEMP%\zefir_server_new.py" 2>nul
del "%TEMP%\zefir_version_remote.txt" 2>nul

echo.
echo ╔══════════════════════════════════════════╗
echo ║  ✅ ОБНОВЛЕНИЕ УСТАНОВЛЕНО!            ║
echo ║  Версия: %REMOTE_VERSION%              ║
echo ║  Бэкап: %BACKUP_DIR%\%BACKUP_NAME%     ║
echo ╚══════════════════════════════════════════╝

:: Записываем в лог
echo [%date% %time%] Обновление %CURRENT_VERSION% → %REMOTE_VERSION% >> "%UPDATE_LOG%"

goto :CHECK_UPDATER

:: ===== ПРОВЕРКА ОБНОВЛЕНИЯ UPDATER =====
:CHECK_UPDATER
echo.
echo [6/6] Проверка обновления автообновления...

curl -s -o "%TEMP%\zefir_updater_remote.bat" "%UPDATER_URL%" 2>nul
if %errorlevel% equ 0 (
    :: Сравниваем файлы
    fc "%~f0" "%TEMP%\zefir_updater_remote.bat" >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ОБНОВЛЕНИЕ] Найдена новая версия автообновления!
        echo Обновляю zefir_updater.bat...
        copy /Y "%TEMP%\zefir_updater_remote.bat" "%~f0" >nul
        echo [OK] Автообновление обновлено. Перезапустите.
        start "" "%~f0"
        exit
    )
)

del "%TEMP%\zefir_updater_remote.bat" 2>nul

echo.
echo ╔══════════════════════════════════════════╗
echo ║  ✅ ПРОВЕРКА ЗАВЕРШЕНА                 ║
echo ╚══════════════════════════════════════════╝
echo.
echo Хотите запустить Зефира? (Y/N)
choice /c YN /n /m "Ваш выбор: "
if errorlevel 2 goto :EOF
if errorlevel 1 (
    cls
    echo Запускаю ZEFIR AI...
    python %LOCAL_SERVER%
)

pause
exit /b 0