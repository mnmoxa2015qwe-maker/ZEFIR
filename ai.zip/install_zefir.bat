@echo off
chcp 65001 >nul
title ZEFIR AI - Установщик v5.0

net session >nul 2>&1 || (echo Запусти от имени Администратора! & pause & exit /b 1)

cls
echo.
echo ╔══════════════════════════════════════════════╗
echo ║   ⚡ ZEFIR AI v5.0 - ПОЛНАЯ УСТАНОВКА       ║
echo ║   Python→EXE | C++→EXE | C#→EXE            ║
echo ╚══════════════════════════════════════════════╝
echo.

:: 1. Python
echo [1/8] Python...
python --version >nul 2>&1 || (
    curl -L -o "%TEMP%\python.exe" "https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe"
    start /wait "" "%TEMP%\python.exe" /quiet InstallAllUsers=1 PrependPath=1
    call :RefreshEnv
)
echo OK

:: 2. pip + зависимости
echo [2/8] Зависимости...
pip install --upgrade pip --quiet 2>&1
pip install fastapi uvicorn python-multipart ollama duckduckgo-search Pillow httpx pyinstaller --quiet 2>&1
echo OK

:: 3. Ollama
echo [3/8] Ollama...
ollama --version >nul 2>&1 || (
    curl -L -o "%TEMP%\ollama.exe" "https://ollama.com/download/OllamaSetup.exe"
    start /wait "" "%TEMP%\ollama.exe"
)
curl -s http://localhost:11434/api/tags >nul 2>&1 || start "Ollama" /MIN ollama serve
timeout /t 8 /nobreak >nul
echo OK

:: 4. Модели
echo [4/8] Модели...
ollama list | findstr "llama3.2" >nul 2>&1 || ollama pull llama3.2:latest
ollama list | findstr "llava" >nul 2>&1 || ollama pull llava:latest
echo OK

:: 5. MinGW (C++)
echo [5/8] C++ компилятор...
where g++ >nul 2>&1 || (
    echo Скачиваю MinGW...
    curl -L -o "%TEMP%\mingw.zip" "https://github.com/brechtsanders/winlibs_mingw/releases/download/14.2.0posix-18.1.8-12.0.0-ucrt-r1/winlibs-x86_64-posix-seh-gcc-14.2.0-mingw-w64ucrt-12.0.0-r1.zip"
    powershell Expand-Archive "%TEMP%\mingw.zip" "C:\MinGW" -Force
    setx PATH "%PATH%;C:\MinGW\bin" /M
    call :RefreshEnv
)
echo OK

:: 6. .NET SDK (C#)
echo [6/8] C# компилятор...
where dotnet >nul 2>&1 || where csc >nul 2>&1 || (
    echo Скачиваю .NET SDK...
    curl -L -o "%TEMP%\dotnet.exe" "https://download.visualstudio.microsoft.com/download/pr/9c1e9b9e-8b9a-4b0e-9d9e-8b9a4b0e9d9e/9c1e9b9e8b9a4b0e9d9e8b9a4b0e9d9e/dotnet-sdk-8.0.100-win-x64.exe"
    start /wait "" "%TEMP%\dotnet.exe" /quiet /norestart
    call :RefreshEnv
)
echo OK

:: 7. Создание ярлыка
echo [7/8] Ярлык...
powershell -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\ZEFIR_AI.lnk');$s.TargetPath='%~dp0start_zefir.bat';$s.WorkingDirectory='%~dp0';$s.Description='ZEFIR AI v5.0';$s.IconLocation='shell32.dll,277';$s.Save()" 2>nul
echo OK

:: 8. Финальный экран
echo [8/8] Готово!
echo.
echo ╔══════════════════════════════════════════════╗
echo ║  ✅ ЗЕФИР УСТАНОВЛЕН!                      ║
echo ║  🚀 python ai_server.py                    ║
echo ║  🌐 http://localhost:8000                  ║
echo ╚══════════════════════════════════════════════╝
echo.
pause
exit /b 0

:RefreshEnv
for /f "tokens=2*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v PATH 2^>nul') do set "SysPath=%%b"
set "PATH=%SysPath%;%PATH%"
goto :eof