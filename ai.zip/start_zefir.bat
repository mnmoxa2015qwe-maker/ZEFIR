@echo off
title ZEFIR AI
curl -s http://localhost:11434/api/tags >nul 2>&1 || start "Ollama" /MIN ollama serve
timeout /t 5 /nobreak >nul
start http://localhost:8000
python ai_server.py
pause